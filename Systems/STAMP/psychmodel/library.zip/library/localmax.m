function[lmax,tonal_flag]=localmax(spl)
%this function finds the local maxima used to calculate tonal maskers
lmax=[];
tonal_flag = spl;
tonal_flag = cat(2,tonal_flag,zeros([512,1]));
for k = 2:1:250
    if k==2&&spl(k)>spl(k-1)&&spl(k)>spl(k+1)&&spl(k)>spl(k+2)+7
        lmax = cat(1,lmax,k);
        tonal_flag(k-1:k+2,2) = 1;
    elseif k>2&&k<63&&spl(k)>spl(k+1)&&spl(k)>spl(k-1)&&spl(k)>spl(k+2)+7&&spl(k)>spl(k-2)+7
        lmax = cat(1,lmax,k);
        tonal_flag(k-2:k+2,2) = 1;
    elseif k>=63&&k<127&&spl(k)>spl(k+1)&&spl(k)>spl(k-1)&&spl(k)>spl(k+2)+7&&spl(k)>spl(k-2)+7&&spl(k)>spl(k+3)+7&&spl(k)>spl(k-3)+7
        lmax = cat(1,lmax,k);
        tonal_flag(k-3:k+3,2) = 1;
    elseif k>=127&&k<=256&&spl(k)>spl(k+1)&&spl(k)>spl(k-1)&&spl(k)>spl(k+2)+7&&spl(k)>spl(k-2)+7&&spl(k)>spl(k+6)+7&&spl(k)>spl(k-6)+7
        lmax = cat(1,lmax,k);
        tonal_flag(k-6:k+6,2) = 1;
    end
end