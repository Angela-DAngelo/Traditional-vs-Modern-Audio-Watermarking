function[out]=bin2bark(in)
%converts bin number to bark scale
global F;
out=f2bark(F(in));