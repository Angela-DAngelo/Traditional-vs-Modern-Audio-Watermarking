function[subtones,subnoise]=subsample(tones,noise)
%this function decimates the masker bins according to the scheme in step 3
%down to 106 bins
subtones=[];
subnoise=[];
counter=1;
if isempty(tones)==1
subtones=tones;
else    
for k=1:1:size(tones,1)
if tones(k,1)>=1&&tones(k,1)<=48
    subtones(k,:)=tones(k,:);
elseif tones(k,1)>=49&&tones(k,1)<=96
    subtones(k,:)=[tones(k,1)+mod(tones(k,1),2) tones(k,2)];
elseif tones(k,1)>=97&&tones(k,1)<=232
    subtones(k,:)=[(tones(k,1)+3)-mod(tones(k,1)-1,2) tones(k,2)];
end
end
end
if isempty(noise)==1
subnoise=noise;
else    
for k=1:1:size(noise,1)
if noise(k,1)>=1&&noise(k,1)<=48
    subnoise(k,:)=noise(k,:);
elseif noise(k,1)>=49&&noise(k,1)<=96
    subnoise(k,:)=[noise(k,1)+mod(noise(k,1),2) noise(k,2)];
elseif noise(k,1)>=97&&noise(k,1)<=232
    subnoise(k,:)=[(noise(k,1)+3)-mod(noise(k,1)-1,2) noise(k,2)];
end
end
end