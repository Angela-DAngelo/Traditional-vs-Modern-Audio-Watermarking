function[normalized] = normalizer(data,N)
%normalization of frame after using wavread w/ type double
normalized = data/N;
